package com.niit.SweetTooth.DAO;

public class UserDAO {
	public boolean isValidCredentials(String username, String password) {
		if (username.equals("SweetTooth") && password.equals("sweets4life")) {
			return true;
		}
		return false;
	}
}

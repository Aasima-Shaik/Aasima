package com.niit.shopingcart.frontcontroller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HomeLoad {
	@RequestMapping("/")
	public ModelAndView homePage()
	{
		System.out.println("I am in homepage of controller");
		return new ModelAndView("index");
	}
	
	@RequestMapping("index1")
	public ModelAndView index1()
	{
		System.out.println("I am in homepage of controller");
		return new ModelAndView("index1");
	}
	
	@RequestMapping("login")
	public ModelAndView login()
	{
		System.out.println("I am in login page of controller");
		return new ModelAndView("login");
	}
	
	@RequestMapping("logOut")
	public ModelAndView logOut()
	{
		System.out.println("I am in logOut page of controller");
		return new ModelAndView("index");
	}
	
	@RequestMapping("adminHome")
	public ModelAndView adminHome()
	{
		System.out.println("I am in adminHome page of controller");
		return new ModelAndView("adminHome");
	}
	
	@RequestMapping("paymentDetails")
	public ModelAndView pay()
	{
		System.out.println("I am in payment details page of controller");
		return new ModelAndView("paymentDetails");
	}
	
	@RequestMapping("cupcake")
	public ModelAndView cupcake()
	{
		System.out.println("I am in cupcake details page of controller");
		return new ModelAndView("cupcakes");
	}
	
	@RequestMapping("search")
	public ModelAndView search()
	{
		System.out.println("I am in search using angularJs page of controller");
		return new ModelAndView("search");
	}
	
	@RequestMapping("aboutUs")
	public ModelAndView aboutUs()
	{
		System.out.println("I am in AboutUs page of controller");
		return new ModelAndView("aboutUs");
	}
	
	@RequestMapping("contactUs")
	public ModelAndView contactUs()
	{
		System.out.println("I am in contactUs page of controller");
		return new ModelAndView("contactUs");
	}
	
	@RequestMapping("registerPage")
	public ModelAndView registerPage()
	{
		System.out.println("I am in register page of controller");
		return new ModelAndView("register");
	}
	
	@RequestMapping("thanksPage")
	public ModelAndView thanksPage()
	{
		System.out.println("I am in thank you page of controller");
		return new ModelAndView("thankyou");
	}
	
}

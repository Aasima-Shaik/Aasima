package com.niit.shopingcart.test;

public class UserDetails {

}

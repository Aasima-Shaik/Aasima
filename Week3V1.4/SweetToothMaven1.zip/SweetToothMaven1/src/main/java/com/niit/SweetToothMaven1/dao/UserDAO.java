package com.niit.SweetToothMaven1.dao;

import org.springframework.stereotype.Repository;

@Repository
public class UserDAO {
	public boolean isValidUser(String username,String password)
	  {
	  if(username.equals("niit") && password.equals("12345"))
	  {
		  return true;
		  
	  }
	  else
	  {
		  return false;
	  }
	}
}
